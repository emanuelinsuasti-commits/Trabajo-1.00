import os

ARCHIVO = "salida.txt"

def ingresar_paciente():
    nombre = input("Ingrese nombre: ")
    apellido = input("Ingrese apellido: ")
    edad = input("Ingrese edad: ")

    if os.path.exists(ARCHIVO):
        with open(ARCHIVO, "r") as f:
            lineas = f.readlines()
            numero = len(lineas) + 1
    else:
        numero = 1

    with open(ARCHIVO, "a") as f:
        f.write(f"{numero}|{nombre}|{apellido}|{edad}|\n")

    print(" Paciente guardado correctamente\n")


def ver_pacientes():
    if not os.path.exists(ARCHIVO):
        print(" No hay datos aún.\n")
        return

    with open(ARCHIVO, "r") as f:
        contenido = f.read()
        print("\n Contenido del archivo:")
        print(contenido)


def menu():
    while True:
        print("===== MENÚ =====")
        print("1. Ingresar paciente")
        print("2. Ver archivo")
        print("3. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            ingresar_paciente()
        elif opcion == "2":
            ver_pacientes()
        elif opcion == "3":
            print(" Saliendo del programa")
            break
        else:
            print(" Opción inválida\n")

menu()