import os

CARPETA_ENTRADA = r"C:\Users\insua\Desktop\TAREA info\patients"
CARPETA_SALIDA = r"C:\Users\insua\Desktop\TAREA info\his"
ARCHIVO_SALIDA = "hce.txt"


def procesar_archivos():
    print("Ruta actual:", os.getcwd())
    print("Existe carpeta:", os.path.exists(CARPETA_ENTRADA))

    if not os.path.exists(CARPETA_ENTRADA):
        print(" No existe la carpeta")
        return

    if not os.path.exists(CARPETA_SALIDA):
        os.makedirs(CARPETA_SALIDA)

    ruta_salida = os.path.join(CARPETA_SALIDA, ARCHIVO_SALIDA)

    pacientes_procesados = []

    archivos = os.listdir(CARPETA_ENTRADA)
    print("Archivos encontrados:", len(archivos))

    for archivo in archivos:
        if archivo.endswith(".txt"):
            ruta_archivo = os.path.join(CARPETA_ENTRADA, archivo)
            print(f"\nLeyendo: {archivo}")

            with open(ruta_archivo, "r", encoding='utf-8', errors='ignore') as f:
                contenido = f.read()
                

                lineas = contenido.split("\n")
                pacientes_en_archivo = 0
                
                for linea in lineas:
                    linea = linea.strip()
                    
                    linea = linea.replace("¬", "").replace("\r", "")
                    
            
                    if "3O|" in linea:
                    
                        if not linea.startswith("3O|"):
                            idx = linea.find("3O|")
                            linea = linea[idx:]
                        
                        datos = linea.split("|")
                        if len(datos) >= 8:
                            id_paciente = datos[2] if len(datos) > 2 else ""
                            nombre_completo = datos[4] if len(datos) > 4 else ""
                            eps = datos[6] if len(datos) > 6 else ""
                            edad = datos[7] if len(datos) > 7 else ""
                            genero = datos[23] if len(datos) > 23 else ""
                            fecha_nac = ""
                            
                            if nombre_completo:
                           
                                nombre_completo = nombre_completo.strip("^")
                               
                                if "^^" in nombre_completo:
                                    nombre_completo = nombre_completo.split("^^")[0]
                               
                                nombre_completo = nombre_completo.rstrip("0123456789")
                                
                          
                                partes_nombre = nombre_completo.split()
                                if len(partes_nombre) >= 2:
                                    nombre = partes_nombre[0].strip()
                                    apellido = " ".join(partes_nombre[1:]).strip()
                                elif len(partes_nombre) == 1:
                                    nombre = partes_nombre[0].strip()
                                    apellido = ""
                                else:
                                    nombre = ""
                                    apellido = ""
                            else:
                                nombre = ""
                                apellido = ""
                            
                            if nombre and apellido:
                                print(f"   {nombre} {apellido} - Edad: {edad} - EPS: {eps}")
                                pacientes_en_archivo += 1
                                pacientes_procesados.append((id_paciente, nombre, apellido, edad, genero, fecha_nac, eps))
                    
                
                    elif linea.startswith("PAD|"):
                        datos = linea.split("|")
                        if len(datos) >= 8:
                            nombre_completo = datos[5] if len(datos) > 5 else ""
                            id_paciente = datos[4] if len(datos) > 4 else ""
                            genero = datos[6] if len(datos) > 6 else ""
                            edad = datos[7] if len(datos) > 7 else ""
                            eps = ""
                            fecha_nac = ""
                            
                            if nombre_completo:
                                partes = nombre_completo.split("^")
                                apellido = partes[0].strip() if len(partes) > 0 else ""
                                nombre = partes[1].strip() if len(partes) > 1 else ""
                            else:
                                nombre = ""
                                apellido = ""
                            
                            if nombre and apellido:
                                print(f"   {nombre} {apellido} - Edad: {edad} - Género: {genero}")
                                pacientes_en_archivo += 1
                                pacientes_procesados.append((id_paciente, nombre, apellido, edad, genero, fecha_nac, eps))
                
                if pacientes_en_archivo == 0:
                    print(f"  No se encontraron datos con formato reconocido")

   
    with open(ruta_salida, "w") as salida:
        salida.write("|Id|Nombre|Apellido|Edad|Genero|FechaNacimiento|EPS\n")
        
        for paciente in pacientes_procesados:
            id_p, nombre, apellido, edad, genero, fecha_nac, eps = paciente
            salida.write(f"|{id_p}|{nombre}|{apellido}|{edad}|{genero}|{fecha_nac}|{eps}\n")

    print(f"\n{len(pacientes_procesados)} pacientes procesados")
    print(f"Archivo guardado en: {ruta_salida}")


procesar_archivos()